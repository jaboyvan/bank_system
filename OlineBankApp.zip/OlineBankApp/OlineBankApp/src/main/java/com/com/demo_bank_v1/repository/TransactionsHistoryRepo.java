//package com.com.demo_bank_v1.repository;
//
//import com.com.demo_bank_v1.models.TransactionHistory;
//import org.springframework.data.jpa.repository.JpaRepository;
//
//public interface TransactionsHistoryRepo extends JpaRepository<TransactionHistory,Integer> {
//
//}
